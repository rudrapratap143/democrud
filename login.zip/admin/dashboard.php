<?php

  session_start();
if($_SESSION['uid']){
   
}
else{
    header('location:index.php');

}
include("header.php");
?>
<html>
<head>
    <title>Admin dashboard Panel</title>
    
    <!---======================Bootstrap cdn===========-->
       <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
   
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <!---======================/Bootstrap cdn===========-->
    
    
    </head>
    <body>
    <h3 class="jumbotron text-center">Admin Dashboard</h3>
<div class="container">
      <div class="card-deck">
        <div class="card bg-primary">
             <img class="card-img-top" src="images/2.jpg" alt="Card image" style="margin: auto;">  
          <div class="card-body text-center">
            <a href="insertinfo.php" class="stretched-link btn btn-success">Insert Student Info</a>
         </div>
          </div>
          
         
        <div class="card bg-primary">
             <img class="card-img-top" src="images/2.jpg" alt="Card image" style="margin: auto;">  
          <div class="card-body text-center">
            <a href="infodelete.php" class="stretched-link btn btn-success">Delete Student Info</a>
         </div>
       </div>
      
          
            <div class="card bg-primary">
             <img class="card-img-top" src="images/2.jpg" alt="Card image" style="margin: auto;">  
          <div class="card-body text-center">
            <a href="profile.php" class="stretched-link btn btn-success">Change User & Password</a>
         </div>  
    </div> 
</div>
        </div>
        <div style="height: 50px;"></div>
   <footer>
        <p class="text-primary text-center"> &copy; 2019 Admin Panel Form. All Rights Reserved | Design by <a href="#">Ashwane Upadhyay</a></p>
    </footer>
        
</body>

</html>