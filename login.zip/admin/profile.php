<?php

  session_start();
if($_SESSION['uid']){
   
}
else{
    header('location:index.php');

}
include("header.php");
?>
<html>
<head>
    <title>Change user & password</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    </head>
    <body>
    <h3 class="jumbotron text-center bg-primary">Change user name & password</h3>
    
    </body>
</html> 

<?php
        
            include("dbcon.php");
           
         $qry="SELECT * FROM `login`";  
            $run=mysqli_query($con,$qry);
            
            if(mysqli_num_rows($run)<1){
                
                echo "<tr><td colspan='8'>No Data !!</td></tr>";
                    
                    
            }
            else{
                $count=0;
                while($data=mysqli_fetch_assoc($run)){
                    $count++;
                ?>
<div class="container">
               <div class="table-responsive">
            <table class="table table-bordered text-center">
               <thead>
                  <tr>
                     <th class="text-center">Id </th>
                     <th class="text-center">User_Id</th>
                     <th class="text-center">Password</th>
                   </tr>
                </thead>
                <tbody>
                <tr>
                    
                       <td><?php echo $data['id'];?></td>
                       <td><?php echo $data['user_id'];?></td>
                       <td><?php echo $data['password'];?></td>
                     
                     
                    </tr>
                 </tbody>
               <?php
                } 
            }
        ?>   
       <div class="card ">
        <div class="card-body">
            <form method="post" action="profile.php" enctype="multipart/form-data">
                <div class="form-group">
                   <label for="email">User Name</label>
                   <input type="text" class="form-control" id="text" name="username" required>
                </div>
                 <div class="form-group">
                   <label for="de">Password</label>
                    <input type="password" class="form-control" id="text" name="password" required>
                </div>
               <button type="submit" class="btn btn-primary" name="submit">Submit</button>
            </form>      
     </div>
        </div>          
     </div> 
    </div>

    
<?php
 if(isset($_POST['submit']))
{
    include("dbcon.php");  
     $username=$_POST["username"];
    $password=$_POST["password"];    
    
$qry="UPDATE `login` SET `user_id` = '$username', `password` = '$password' WHERE `id` = '1'";

    $run=mysqli_query($con,$qry);
    if($run==true){
        ?>
        <script>
            alert("Data updated susessfully ");
            window.open('',"_self");
       </script>
            
            <?php
    }
    else{
        echo "No Data Insert";
    }
 }


?>
                