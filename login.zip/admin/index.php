<!DOCTYPE html>
<html lang="en">

<head>
    <title>Schoole Login Form a Responsive </title>
    <!-- meta tags -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="keywords" content="Art Sign Up Form Responsive Widget, Audio and Video players, Login Form Web Template, Flat Pricing Tables, Flat , Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design"
    />
    <!-- /meta tags -->
    <!-- custom style sheet -->
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <!-- /custom style sheet -->
    <!-- fontawesome css -->
    <link href="css/fontawesome-all.css" rel="stylesheet" />
    <!-- /fontawesome css -->
  

</head>


<body>
    <h1>Admin Login Form</h1>
    <div class=" aml-login-form">
        <h2>Login Here</h2>
        <form action="index.php" method="post">

            <div class=" aml-form-group">
                <label>Username:</label>
                <div class="group">
                    <i class="fas fa-user"></i>
                    <input type="text" class="form-control" placeholder="Username" name="name" required="required" />
                </div>
            </div>
            <div class=" aml-form-group">
                <label>Password:</label>
                <div class="group">
                    <i class="fas fa-unlock"></i>
                    <input type="password" class="form-control" placeholder="Password" name="pass" required="required" />
                </div>
            </div>
            <div class="forgot">
                <a href="#">Forgot Password?</a>
                <p><input type="checkbox">Remember Me</p>
            </div>
            <button type="submit" name="submit">Login</button>
        </form>
        <p class=" aml-register-p">Don't have an account?<a href="#" class="register"> Register</a></p>
    </div>
    <footer>
        <p class="copyright-agileinfo"> &copy; 2018 Material Login Form. All Rights Reserved | Design by <a href="#">Ashwane Upadhyay</a></p>
    </footer>

</body>

</html>


<?php
    include("dbcon.php");
 
  if(isset($_POST["submit"])){
      $user=$_POST["name"];
      $pass=$_POST["pass"];
    $qry="SELECT * FROM `login` WHERE `user_id`='$user' AND `password`='$pass'";  
      $run=mysqli_query($con,$qry);
      $row=mysqli_num_rows($run);
      if($row<1){
          ?>
           <script>
            alert ("User and Password Not match !!");
         </script>

      <?php
      }
      else {
      $data=mysqli_fetch_assoc($run);
      $id=$data["id"];
        session_start();
      $_SESSION["uid"]=$id;
          
      header('location:dashboard.php');
     
  }
      }



?>
