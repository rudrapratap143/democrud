<?php
session_start();
if($_SESSION['uid']){
}

else{
    header('location:index.php');
}
include("header.php");
?>
<html>
<head>
    <title>Update Student Data</title>
        <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
  
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    </head>
   <body>
    <form method="post" action="delete.php" enctype="multipart/form-data">
    
       </form>
     <div class="table-responsive">
         <h3 class="text-center jumbotron">Delete Record & insert & Update</h3>
            <table class="table table-bordered">
               <thead>
                  <tr>
                     <th class="text-center">No.</th>
                     <th class="text-center">Image</th>
                     <th class="text-center">Title</th>
                     <th class="text-center">Description</th>
                     <th class="text-center">Delete</th>
                   </tr>
                </thead>
     <?php
        
            include("dbcon.php");
           
         $qry="SELECT * FROM `pdata`";  
            $run=mysqli_query($con,$qry);
            
            if(mysqli_num_rows($run)<1){
                
                echo "<tr><td colspan='8'>No Data !!</td></tr>";
                    
                    
            }
            else{
                $count=0;
                while($data=mysqli_fetch_assoc($run)){
                    $count++;
                ?>
                <tbody>
                <tr>
                    <td><?php echo $count;?></td>
                       <td><?php echo $data['document'];?></td>
                       <td><?php echo $data['date'];?></td>
                       <td><?php echo $data['number'];?></td>
                       <td><?php echo $data['country'];?></td>
                       
                      
                       <td><a class="btn btn-warning" href="infodeletedata.php?sid=<?php echo $data['id'];  ?> ">Delete</a></td>
                    </tr>
                 </tbody>
               <?php
                }
                
            
            
            
            
            
            
        }
        
        ?>       
       </table>
    </body>
</html>
