<?php
 $con=mysqli_connect("localhost","root","","passport");
    if($con==true){
        
        echo "";
    } 
   else
   {
       echo "connection faild";
   }

?>