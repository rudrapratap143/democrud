<?php
session_start();
if($_SESSION['uid']){
   


}

else{
    header('location:index.php');
}

    include("dbcon.php");
$id=$_GET['sid'];
$qry="DELETE FROM `info` WHERE `id`='$id'";
$run=mysqli_query($con,$qry);

if($run==true){
    ?>
     <script>
        alert("Data Deleted !!"); 
         window.open("infodelete.php","_self");
     </script>

    <?php
}
else{
     echo "No delete data..";
}




?>